"""HydroWatch flood-change segmentation package."""

__version__ = "0.1.0"
